export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ ok: false, error: 'Method not allowed' });
  }

  const { company = '', name = '', email = '', message = '', website = '' } = req.body || {};

  // Honeypot for basic bot filtering.
  if (website) {
    return res.status(200).json({ ok: true });
  }

  if (!name || !email || !message) {
    return res.status(400).json({ ok: false, error: '必須項目を入力してください。' });
  }

  const apiKey = process.env.RESEND_API_KEY;
  const to = process.env.CONTACT_TO_EMAIL;
  const from = process.env.CONTACT_FROM_EMAIL || 'Freelancers Cloud <onboarding@resend.dev>';

  if (!apiKey || !to) {
    return res.status(503).json({
      ok: false,
      error: 'お問い合わせフォームのメール送信設定が未完了です。'
    });
  }

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from,
        to: [to],
        reply_to: email,
        subject: `【Freelancers Cloud】お問い合わせ - ${name}`,
        text: [
          'Freelancers Cloudのお問い合わせフォームから送信がありました。',
          '',
          `会社名: ${company || '未入力'}`,
          `お名前: ${name}`,
          `メール: ${email}`,
          '',
          'ご相談内容:',
          message
        ].join('\\n')
      })
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      console.error('Resend error:', data);
      return res.status(502).json({ ok: false, error: 'メール送信に失敗しました。' });
    }

    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ ok: false, error: 'サーバーエラーが発生しました。' });
  }
}
