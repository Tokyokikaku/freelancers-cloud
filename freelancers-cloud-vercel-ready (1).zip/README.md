# Freelancers Cloud LP — Vercel / GitHub版

## 構成
- `index.html` — LP本体
- `assets/` — 画像
- `api/contact.js` — Vercel Serverless Function（問い合わせ送信）
- `vercel.json` — Vercel設定

## 公開
このリポジトリをVercelにImportすると、そのまま静的サイトとして公開できます。
Framework Presetは `Other`、Build Commandは不要、Output Directoryは `.` のままでOKです。

## 問い合わせフォーム
Netlify Forms依存を削除し、`/api/contact` を使う構成に変更済みです。
メール送信にはVercel側で以下のEnvironment Variablesを設定します。

- `RESEND_API_KEY`
- `CONTACT_TO_EMAIL`
- `CONTACT_FROM_EMAIL`（任意。独自ドメインをResendで認証した後に設定）

未設定でもサイト自体は公開できますが、フォーム送信時に「メール送信設定が未完了」と表示されます。
